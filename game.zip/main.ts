import { Game } from "./model/game/game.js";


let game: Game = new Game();
game.create();
game.gameLoop();