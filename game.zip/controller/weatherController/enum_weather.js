export var enumWeater;
(function (enumWeater) {
    enumWeater[enumWeater["rain"] = 0] = "rain";
    enumWeater[enumWeater["sun"] = 1] = "sun";
    enumWeater[enumWeater["snow"] = 2] = "snow";
    enumWeater[enumWeater["clouds"] = 3] = "clouds";
    enumWeater[enumWeater["wind"] = 4] = "wind";
})(enumWeater || (enumWeater = {}));
