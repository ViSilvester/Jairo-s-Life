export class Vec2 {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}
export class Vec3 {
    constructor(x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
