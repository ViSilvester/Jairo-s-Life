export enum enumWeater {
    rain, sun, snow, clouds, wind,
}