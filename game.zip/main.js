import { Game } from "./model/game/game.js";
let game = new Game();
game.create();
game.gameLoop();
